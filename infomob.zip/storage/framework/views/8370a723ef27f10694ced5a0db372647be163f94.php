<?php $__env->startSection('content'); ?>

<h1 class="page-header">Организации</h1>

<a href="/admin/organizations/create" class="btn btn-lg btn-primary"><i class="fa fa-plus"></i> Добавить организацию</a>
<br><br>

<hr>
<div class="row">
	<div class="col-md-12">
		<?php if(isset($chosenCity)): ?>
		<div id="div_admin_citypicker">
			<select id="admin_citypicker">
	            <?php foreach(App\City::orderBy("order")->get() as $city): ?>
	                <option value="<?php echo e($city->id); ?>"
	                    <?php if($chosenCity->id == $city->id): ?> selected <?php endif; ?> 
	                >
	                    <?php echo e($city->name); ?>

	                </option>
	            <?php endforeach; ?>
	        </select>
		</div>
		<?php endif; ?>

		<div id="div_admin_topten">
			<a href="?topten=1" class="btn btn-default"><i class="fa fa-star"></i> ТОП организации</a>
		</div>
	</div>
</div>
<hr>

<div class="row">
	<div class="col-md-12">
		
		<table id="myTable" class="display" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>ID</th>
					<th>NAME</th>
					<th>DESCRIPTION</th>
					<th>STATUS</th>
					<th>ACTIONS</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($organizations as $organization): ?>
					<tr>
						<td><?php echo e($organization->id); ?></td>
						<td>
							<a href="/admin/organizations/<?php echo e($organization->id); ?>/edit">
								<?php echo e($organization->name); ?>

							</a>
						</td>
						<td><?php echo e($organization->description); ?></td>
						<td><?php echo e($organization->status); ?></td>
						<td width="200px">
							<a href="#" <?php if($organization->order != 9999): ?> data-topten="1" class="btn btn-sm btn-warning" <?php else: ?> data-topten="0" class="btn btn-sm btn-default"  <?php endif; ?>  title="В ТОП!" id="topit"><i class="fa fa-star"></i></a>
							<a href="/admin/organizations/<?php echo e($organization->id); ?>/edit" class="btn btn-sm btn-default" title="Редактировать"><i class="fa fa-pencil"></i></a>
							<a href="/admin/organizations/<?php echo e($organization->id); ?>/remove" class="btn_remove btn btn-sm btn-default" title="Удалить"><i class="fa fa-trash"></i></a>
							<a href="/admin/organizations/<?php echo e($organization->id); ?>/edit#tableBranches" class="btn btn-sm btn-default" title="Филиалы"><i class="fa fa-bars"></i></a>
							<a href="/admin/organizations/<?php echo e($organization->id); ?>/createbranch" class="btn btn-sm btn-default" title="Добавить филиал"><i class="fa fa-plus"></i></a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

	</div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts_body'); ?>
	$('#myTable').DataTable({
		paging: true,
		aaSorting:[]
	});

	$('#topit').click(function($e) {
		var topTen = $(this).data('topten');

		if (topTen == 1) {
			alert('Убрать из топа (ajax request)');
		} else {
			alert('Добавить в топ и перейти для установления порядка');
		}
	});
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>