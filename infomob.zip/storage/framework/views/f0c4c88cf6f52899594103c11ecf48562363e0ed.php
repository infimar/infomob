<?php $__env->startSection('title'); ?>
    <?php echo e($organization->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('organization', $category, $subcategory, $organization); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('search'); ?>
    <section class="well_search bg1">
        <div class="container">
            <div class="h1 clr-black text-center">
                Найдите то, что искали
            </div>

            <?php echo Form::open(array('url' => '', 'class' => 'search-form-all')); ?>

            <label class="search-form_label">
                <?php echo e(Form::text('s', $first_name = null, array('class' => 'search-form_input', 'placeholder' => 'Компании,  Сервисы,  Банкоматы'))); ?>

                <span class="search-form_liveout"></span>
            </label>
            <?php echo e(Form::submit('Поиск', array('class' => 'search-form_submit btn btn-primary'))); ?>

            <?php echo Form::close(); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <section class="well2">
            <div class="container">
                <h2><?php echo e($organization->name); ?></h2>
                <hr>
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-8">
                        <div class="row">
                            <div class="col-xs-12">
                                <h4>Деятельность</h4>
                                <p><?php echo e(nl2br($organization->description)); ?></p>
                            </div>
                        </div>

                        <?php if(!$branches->isEmpty()): ?>
                            <div class="row">
                                <div class="col-xs-12">
                                    <h4>Филиалы в городе <?php echo e($city->name); ?></h4>
                                    <ul class="list-group">
                                        <?php foreach($branches as $branch): ?>
                                            <li class="list-group-item">
                                                <a href="/branch/<?php echo e($branch->id); ?>/<?php echo e($subcategory->id); ?>"><?php echo e($branch->name); ?></a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(!$otherBranches->isEmpty()): ?>
                            <div class="row">
                                <div class="col-xs-12">
                                    <h4>Другие филиалы</h4>
                                    <ul class="list-group">
                                        <?php foreach($otherBranches as $branch): ?>
                                            <li class="list-group-item">
                                                <a href="/branch/<?php echo e($branch->id); ?>/<?php echo e($subcategory->id); ?>"><?php echo e($branch->name); ?></a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>