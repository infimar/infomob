<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('search'); ?>
    <section class="well_search bg1">
        <div class="container">

            <div class="h1 clr-black text-center">
                404<br>
                Страница которую вы ищете, не найдена<br>
                Найдите то, что искали
            </div>

            <?php echo Form::open(array('url' => '', 'class' => 'search-form-all')); ?>

            <label class="search-form_label">
                <?php echo e(Form::text('s', $first_name = null, array('class' => 'search-form_input', 'placeholder' => 'Компании,  Сервисы,  Банкоматы'))); ?>

                <span class="search-form_liveout"></span>
            </label>
            <?php echo e(Form::submit('Поиск', array('class' => 'search-form_submit btn btn-primary'))); ?>

            <?php echo Form::close(); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>