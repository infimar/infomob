<?php $__env->startSection('title'); ?>
    <?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('category', $category, $activeSubcategory); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('search'); ?>
    <section class="well_search bg1">
        <div class="container">
            <div class="h1 clr-black text-center">
                Найдите то, что искали
            </div>

            <?php echo Form::open(array('url' => '', 'class' => 'search-form-all')); ?>

            <label class="search-form_label">
                <?php echo e(Form::text('s', $first_name = null, array('class' => 'search-form_input', 'placeholder' => 'Компании,  Сервисы,  Банкоматы'))); ?>

                <span class="search-form_liveout"></span>
            </label>
            <?php echo e(Form::submit('Поиск', array('class' => 'search-form_submit btn btn-primary'))); ?>

            <?php echo Form::close(); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <section class="well2">
            <div class="container">
                <div class="left_block">
                    <h3><?php echo e($category->name); ?></h3>
                    <div>
                        <ul class="sf-menu1">
                            <?php foreach($children as $child): ?>
                                <li class="active">
                                    <a href="/category/<?php echo e($category->slug); ?>?subcategory=<?php echo e($child->slug); ?>"
                                        <?php if($activeSubcategory->slug == $child->slug): ?>
                                            style="color: #2196F3;"
                                        <?php endif; ?>
                                    >
                                        <?php echo e($child->name); ?>

                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <div class="right_block">
                    <?php if(count($organizations) > 0): ?>
                        <?php foreach($organizations as $organization): ?>
                            <div class="organization_item">
                                <a href="/organization/<?php echo e($organization->id); ?>">
                                    <?php if(!$organization->branches->isEmpty() && !$organization->branches[0]->photos->isEmpty()): ?>
                                        <div class="thumbnail_100">
                                            <img src="<?php echo e(asset('images/photos/' . $organization->branches[0]->photos[0]->path)); ?>">
                                        </div>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/photos/nologo.png')); ?>">
                                    <?php endif; ?>
                                </a>

                                <div class="organization_item_text">
                                    <div class="organization_name_title">
                                        <a href="/organization/<?php echo e($organization->id); ?>/<?php echo e($activeSubcategory->id); ?>"><?php echo e($organization->name); ?></a>
                                    </div>
                                    <div class="organization_short_description">
                                        <?php echo e($organization->description); ?> <br>
                                        
                                        <?php if(!$organization->branches->isEmpty() && !$organization->branches[0]->phones->isEmpty()): ?>
                                            Контакты:<br>
                                            <?php foreach($organization->branches[0]->phones as $phone): ?>
                                                <?php echo e($phone->code_country); ?> (<?php echo e($phone->code_operator); ?>) <?php echo e($phone->number); ?> <?php if(!empty($phone->contact_person)): ?> - <?php echo e($phone->contact_person); ?> <?php endif; ?><br>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div style="clear: both;"></div> 
                            </div>
                        <?php endforeach; ?>
                    
                        <?php echo e($organizations->appends(['subcategory' => $activeSubcategory->slug])->links()); ?>

                    <?php else: ?>
                        <span style="margin-left: 20px">Нет совпадений</span>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>