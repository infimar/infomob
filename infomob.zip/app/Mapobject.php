<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mapobject extends Model
{
    //
}
