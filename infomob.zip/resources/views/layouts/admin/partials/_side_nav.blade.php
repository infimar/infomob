<ul class="nav nav-sidebar">
  <li id="organizations_index"><a href="/admin/organizations">Организации</a></li>
  <li id="organizations_create"><a href="/admin/organizations/create">Добавить организацию</a></li>
  <li class="nav-divider"></li>
</ul>

<ul class="nav nav-sidebar">
  <li id="categories_index"><a href="/admin/categories">Категории</a></li>
  <li id="categories_create"><a href="/admin/categories/create">Добавить категорию</a></li>
  <li class="nav-divider"></li>
</ul>

<ul class="nav nav-sidebar">
  <li><a href="/admin/cityservices">Специальные службы</a></li>
  <li><a href="/admin/cityservices/create">Добавить cлужбу</a></li>
  <li class="nav-divider"></li>
</ul>

<ul class="nav nav-sidebar">
  <li><a href="/admin/seasons">Сезоны</a></li>
  <li><a href="/admin/organseasons/create">Добавить сезон</a></li>
  {{-- <li class="nav-divider"></li> --}}
</ul>

{{-- <ul class="nav nav-sidebar">
  <li><a href="">Nav item again</a></li>
  <li><a href="">One more nav</a></li>
  <li><a href="">Another nav item</a></li>
</ul> --}}